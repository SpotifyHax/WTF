package com.openwebinars.hibernate.primerproyectohbnjpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class App 
{
    public static void main( String[] args )
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HibernateJPA_GeneracionEntidades");
        
        EntityManager em = emf.createEntityManager();
        
//        User user = new User();
//    	user.setId(3);
//    	user.setUsername("María");
//    	user.setUserMessage("Hello World JPA from María");
//    	
//    	User user2 = new User();
//    	user2.setId(4);
//    	user2.setUsername("Antonio");
//    	user2.setUserMessage("Hello World JPA from Antonio");
//    	
//    	em.getTransaction().begin();
//    	
//    	em.persist(user);
//    	em.persist(user2);
//    	
//    	
//    	em.getTransaction().commit();
        
        
        em.close();
        emf.close();
    }
}
