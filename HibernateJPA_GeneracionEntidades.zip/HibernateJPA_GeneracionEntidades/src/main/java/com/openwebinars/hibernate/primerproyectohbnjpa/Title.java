package com.openwebinars.hibernate.primerproyectohbnjpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the title database table.
 * 
 */
@Entity
@NamedQuery(name="Title.findAll", query="SELECT t FROM Title t")
public class Title implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	@Column(name="date_added")
	private String dateAdded;

	private String description;

	private String duration;

	private String name;

	@Column(name="num_ratings")
	private int numRatings;

	private String rating;

	@Column(name="release_year")
	private String releaseYear;

	@Column(name="user_rating")
	private float userRating;

	//bi-directional many-to-many association to Actor
	@ManyToMany
	@JoinTable(
		name="title_actor"
		, joinColumns={
			@JoinColumn(name="title_id")
			}
		, inverseJoinColumns={
			@JoinColumn(name="actor_id", referencedColumnName="id")
			}
		)
	private List<Actor> actors;

	//bi-directional many-to-many association to Director
	@ManyToMany
	@JoinTable(
		name="title_director"
		, joinColumns={
			@JoinColumn(name="title_id")
			}
		, inverseJoinColumns={
			@JoinColumn(name="director_id")
			}
		)
	private List<Director> directors;

	//bi-directional many-to-many association to Category
	@ManyToMany
	@JoinTable(
		name="title_category"
		, joinColumns={
			@JoinColumn(name="title_id")
			}
		, inverseJoinColumns={
			@JoinColumn(name="category_id", referencedColumnName="id")
			}
		)
	private List<Category> categories;

	public Title() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDateAdded() {
		return this.dateAdded;
	}

	public void setDateAdded(String dateAdded) {
		this.dateAdded = dateAdded;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDuration() {
		return this.duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNumRatings() {
		return this.numRatings;
	}

	public void setNumRatings(int numRatings) {
		this.numRatings = numRatings;
	}

	public String getRating() {
		return this.rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getReleaseYear() {
		return this.releaseYear;
	}

	public void setReleaseYear(String releaseYear) {
		this.releaseYear = releaseYear;
	}

	public float getUserRating() {
		return this.userRating;
	}

	public void setUserRating(float userRating) {
		this.userRating = userRating;
	}

	public List<Actor> getActors() {
		return this.actors;
	}

	public void setActors(List<Actor> actors) {
		this.actors = actors;
	}

	public List<Director> getDirectors() {
		return this.directors;
	}

	public void setDirectors(List<Director> directors) {
		this.directors = directors;
	}

	public List<Category> getCategories() {
		return this.categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}

}